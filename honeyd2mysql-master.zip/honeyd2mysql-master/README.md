Honeyd2MySQL
============

Honeyd2MySQL is a simple script that extracts data from Honeyd logs and inserts them in a MySQL database.
